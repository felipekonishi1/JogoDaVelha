#ifndef JOGO_DA_VELHA_H
#define JOGO_DA_VELHA_H

extern char Matriz[3][3];
extern char Jogador1[20];
extern char Jogador2[20];

void InicializarMatriz();
int ValidarMatriz(char letra);
int ValidarCoord(int x, int y);
int ValidarPosVazia(int x, int y);
int GanhouLinhas();
int GanhouColunas();
int GanhouDiagPrincipal();
int GanhouDiagSecundaria();
void Imprimir();
void Jogar();

#endif
