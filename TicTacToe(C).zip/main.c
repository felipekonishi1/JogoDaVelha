#include <stdio.h>
#include "jogo_da_velha.h"

int main() {
    InicializarMatriz();
    printf("Matriz inicializada!\n");

    printf("Digite o nome do Jogador 1: ");
    scanf("%s", Jogador1);
    printf("Digite o nome do Jogador 2: ");
    scanf("%s", Jogador2);

    Jogar();

    return 0;
}
