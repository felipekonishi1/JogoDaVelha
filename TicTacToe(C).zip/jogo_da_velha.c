#include <stdio.h>
#include "jogo_da_velha.h"
//criação da matriz e dos jogadores
char Matriz[3][3];
char Jogador1[20];
char Jogador2[20];

//função responsável por inicializar a matriz e "limpar" o conteúdo
void InicializarMatriz() {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            Matriz[i][j] = ' ';
        }
    }
}

//função para validar a matriz
int ValidarMatriz(char letra) {
    return (letra == 'x' || letra == '0') ? 1 : 0;
}

//função para validar coordenada da matriz (3x3)
int ValidarCoord(int x, int y) {
    return (x >= 0 && x < 3 && y >= 0 && y < 3) ? 1 : 0;
}

//função para validar se a posição da matriz está vazia    
int ValidarPosVazia(int x, int y) {
    return (Matriz[x][y] != 'x' && Matriz[x][y] != '0') ? 1 : 0;
}

//função para ver se algum jogador ganhou na linha
int GanhouLinhas() {
    int aux;
    for (int i = 0; i < 3; i++) {
        aux = 1;
        for (int j = 0; j < 2; j++) {
            if (ValidarMatriz(Matriz[i][j]) && Matriz[i][j] == Matriz[i][j + 1]) {
                aux++;
            }
        }
        if (aux == 3) {
            return 1;
        }
    }
    return 0;
}

//função que verifica se houve algum ganhador nas colunas
int GanhouColunas() {
    int aux;
    for (int i = 0; i < 3; i++) {
        aux = 1;
        for (int j = 0; j < 2; j++) {
            if (ValidarMatriz(Matriz[j][i]) && Matriz[j][i] == Matriz[j + 1][i]) {
                aux++;
            }
        }
        if (aux == 3) {
            return 1;
        }
    }
    return 0;
}

//função para verificar se o jogador ganhou na diagonal principal (0,0; 1,1; 2;2)
int GanhouDiagPrincipal() {
    int aux = 1;
    for (int i = 0; i < 2; i++) {
        if (ValidarMatriz(Matriz[i][i]) && Matriz[i][i] == Matriz[i + 1][i + 1]) {
            aux++;
        }
    }
    return (aux == 3) ? 1 : 0;
}

//função para verificar se o jogador ganhou na diagonal secundária (0,2; 1,1; 2,0)
int GanhouDiagSecundaria() {
    int aux = 1;
    for (int i = 0; i < 2; i++) {
        if (ValidarMatriz(Matriz[i][2 - i]) && Matriz[i][2 - i] == Matriz[i + 1][2 - (i + 1)]) {
            aux++;
        }
    }
    return (aux == 3) ? 1 : 0;
}

//função para imprimir o jogo da velha (linhas e colunas)
void Imprimir() {
    printf("  0   1   2\n");
    for (int l = 0; l < 3; l++) {
        printf("%d ", l);
        for (int c = 0; c < 3; c++) {
            printf(" %c ", Matriz[l][c]);
            if (c < 2) printf("|");
        }
        printf("\n");
        if (l < 2) printf("  ---|---|---\n");
    }
}

//função para o usuário jogar
void Jogar() {
    int x, y, valida, ordem = 1, ganhou = 0, jogadas = 0;

    do {
        do {
            Imprimir();
            printf("Digite a coordenada que deseja jogar (linha e coluna): \n");
            scanf("%d %d", &x, &y);
            valida = ValidarCoord(x, y);
            if (valida == 1) {
                valida += ValidarPosVazia(x, y);
            }
        } while (valida != 2);

        if (ordem == 1) {
            Matriz[x][y] = 'x';
        } else {
            Matriz[x][y] = '0';
        }
        ordem = (ordem == 1) ? 2 : 1;
        jogadas++;

        ganhou = GanhouLinhas() || GanhouColunas() || GanhouDiagPrincipal() || GanhouDiagSecundaria();

    } while (ganhou == 0 && jogadas < 9);

    Imprimir();
    if (ganhou != 0) {
        if (ordem == 2)
            printf("Parabéns você venceu, %s!\n", Jogador1);
        else
            printf("Parabéns você venceu, %s!\n", Jogador2);
    } else {
        printf("Ninguém ganhou :(\n");
    }
}
